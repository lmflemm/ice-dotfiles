<#
.SYNOPSIS
  ICE Release Engineering - Windows-ready bootstrap/check script.

.DESCRIPTION
  Conservative bootstrap for a corporate Windows laptop.

  Design:
  - Windows host tooling is handled with PowerShell + winget where allowed.
  - Linux-style CLI/dev tooling is expected to live in WSL Ubuntu where allowed.
  - No company URLs, credentials, tokens, SSH keys, or secrets are configured.
  - By default this script runs in CHECK-ONLY mode. Use -Install to install.
  - WSL install is opt-in with -InstallWSL because it may require admin rights
    and may be restricted by corporate policy.

.EXAMPLE
  # Safe check-only run
  powershell -ExecutionPolicy Bypass -File .\bootstrap-ice-release-eng-windows.ps1

.EXAMPLE
  # Install approved Windows-side tools using winget
  powershell -ExecutionPolicy Bypass -File .\bootstrap-ice-release-eng-windows.ps1 -Install

.EXAMPLE
  # Install Windows-side tools and attempt WSL Ubuntu install
  powershell -ExecutionPolicy Bypass -File .\bootstrap-ice-release-eng-windows.ps1 -Install -InstallWSL

.EXAMPLE
  # Install optional tools too
  powershell -ExecutionPolicy Bypass -File .\bootstrap-ice-release-eng-windows.ps1 -Install -InstallOpenShiftCli -InstallDockerDesktop

.NOTES
  On a managed company laptop, winget, WSL, Microsoft Store, Docker Desktop, VS Code
  extensions, and admin rights may be restricted. Prefer Company Portal / Software
  Center / internal instructions when available.
#>

[CmdletBinding()]
param(
  [switch]$Install,
  [switch]$InstallWSL,
  [string]$WslDistro = "Ubuntu",
  [switch]$InstallOpenShiftCli,
  [switch]$InstallDockerDesktop,
  [switch]$InstallChefWorkstation,
  [switch]$InstallVsCodeExtensions,
  [switch]$ConfigureGit,
  [string]$GitName = "",
  [string]$GitEmail = "",
  [string]$BootstrapHome = "$env:USERPROFILE\ice-bootstrap"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Info($Message)    { Write-Host "[INFO] $Message" -ForegroundColor Cyan }
function Write-Success($Message) { Write-Host "[SUCCESS] $Message" -ForegroundColor Green }
function Write-Warn($Message)    { Write-Host "[WARN] $Message" -ForegroundColor Yellow }
function Write-Err($Message)     { Write-Host "[ERROR] $Message" -ForegroundColor Red }

function Test-Command {
  param([Parameter(Mandatory=$true)][string]$Name)
  return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

function Test-IsAdmin {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-Winget {
  return (Test-Command "winget")
}

function Test-WingetPackageInstalled {
  param([Parameter(Mandatory=$true)][string]$Id)

  if (-not (Test-Winget)) { return $false }

  try {
    $null = winget list --id $Id --exact --accept-source-agreements 2>$null
    return ($LASTEXITCODE -eq 0)
  } catch {
    return $false
  }
}

function Install-WingetPackage {
  param(
    [Parameter(Mandatory=$true)][string]$Id,
    [Parameter(Mandatory=$true)][string]$Name,
    [string]$Override = ""
  )

  if (-not (Test-Winget)) {
    Write-Warn "winget is unavailable. Install $Name through Company Portal / Software Center if needed."
    return
  }

  if (Test-WingetPackageInstalled -Id $Id) {
    Write-Success "$Name already appears installed ($Id)."
    return
  }

  if (-not $Install) {
    Write-Info "CHECK-ONLY: would install $Name ($Id) with winget. Re-run with -Install to perform."
    return
  }

  Write-Info "Installing $Name ($Id) via winget..."
  $args = @(
    "install",
    "--id", $Id,
    "--exact",
    "--source", "winget",
    "--accept-package-agreements",
    "--accept-source-agreements"
  )

  if ($Override.Trim().Length -gt 0) {
    $args += @("--override", $Override)
  }

  try {
    & winget @args
    if ($LASTEXITCODE -ne 0) {
      Write-Warn "winget returned non-zero exit code while installing $Name."
    }
  } catch {
    Write-Warn "Failed to install $Name via winget: $($_.Exception.Message)"
  }
}

function Configure-GitIfRequested {
  if (-not $ConfigureGit) { return }

  if (-not (Test-Command "git")) {
    Write-Warn "Git is not available yet. Re-run this step after Git is installed."
    return
  }

  if ($GitName.Trim().Length -gt 0) {
    git config --global user.name "$GitName"
    Write-Success "Configured git user.name."
  } else {
    Write-Warn "GitName not provided; user.name not changed."
  }

  if ($GitEmail.Trim().Length -gt 0) {
    git config --global user.email "$GitEmail"
    Write-Success "Configured git user.email."
  } else {
    Write-Warn "GitEmail not provided; user.email not changed."
  }

  git config --global init.defaultBranch main
  git config --global pull.rebase false
  git config --global core.autocrlf false
  Write-Success "Applied conservative Git defaults."
}

function Install-VSCodeExtensionsIfRequested {
  if (-not $InstallVsCodeExtensions) { return }

  if (-not (Test-Command "code")) {
    Write-Warn "VS Code CLI 'code' is not available. Open VS Code once or install it before adding extensions."
    return
  }

  $extensions = @(
    "ms-vscode.PowerShell",
    "ms-vscode-remote.remote-wsl",
    "GitHub.vscode-github-actions",
    "eamodio.gitlens"
  )

  foreach ($extension in $extensions) {
    if (-not $Install) {
      Write-Info "CHECK-ONLY: would install VS Code extension $extension."
      continue
    }

    try {
      code --install-extension $extension --force
    } catch {
      Write-Warn "Could not install VS Code extension $extension: $($_.Exception.Message)"
    }
  }
}

function Install-WSLIfRequested {
  Write-Info "Checking WSL availability..."

  if (Test-Command "wsl.exe") {
    try {
      wsl.exe --status | Out-Host
    } catch {
      Write-Warn "wsl.exe exists but status check failed. WSL may not be initialized or may be blocked by policy."
    }
  } else {
    Write-Warn "wsl.exe was not found."
  }

  if (-not $InstallWSL) {
    Write-Info "Skipping WSL installation. Use -InstallWSL if company policy permits."
    return
  }

  if (-not $Install) {
    Write-Info "CHECK-ONLY: would attempt WSL install. Re-run with -Install -InstallWSL to perform."
    return
  }

  if (-not (Test-IsAdmin)) {
    Write-Warn "WSL installation may require administrator rights. Re-run elevated or request approval if needed."
  }

  try {
    Write-Info "Attempting to install WSL distro: $WslDistro"
    wsl.exe --install -d $WslDistro
    Write-Warn "A reboot may be required before WSL is usable."
  } catch {
    Write-Warn "WSL install failed or is blocked by policy: $($_.Exception.Message)"
  }
}

function New-WslBootstrapScript {
  New-Item -ItemType Directory -Force -Path $BootstrapHome | Out-Null

  $scriptPath = Join-Path $BootstrapHome "bootstrap-ice-release-eng-wsl-ubuntu.sh"
  $script = @'
#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

# -----------------------------------------------------------------------------
# ICE Release Engineering Bootstrap - WSL Ubuntu/Linux Layer
#
# Use this inside WSL Ubuntu after corporate policy confirms WSL is allowed.
#
# Defaults are conservative:
# - installs user-level tools where possible
# - does not configure company URLs, tokens, SSH keys, or credentials
# - does not install Jenkins CLI by default because George indicated Jenkins is not
#   directly supported by this Release Engineering team
#
# Flags:
#   INSTALL_JENKINS_CLI=1 ./bootstrap-ice-release-eng-wsl-ubuntu.sh
#   INSTALL_CHEF_WORKSTATION=1 ./bootstrap-ice-release-eng-wsl-ubuntu.sh
# -----------------------------------------------------------------------------

info() { echo -e "\033[1;34m[INFO]\033[0m $1"; }
success() { echo -e "\033[1;32m[SUCCESS]\033[0m $1"; }
warn() { echo -e "\033[1;33m[WARN]\033[0m $1"; }
error() { echo -e "\033[1;31m[ERROR]\033[0m $1" >&2; }

has() { command -v "$1" >/dev/null 2>&1; }

append_once() {
  local line="$1"
  local file="$2"
  mkdir -p "$(dirname "$file")"
  touch "$file"
  if ! grep -Fqx "$line" "$file"; then
    echo "$line" >>"$file"
  fi
}

SUDO=()
if [[ "${EUID}" -ne 0 ]]; then
  SUDO=(sudo)
fi

INSTALL_JENKINS_CLI="${INSTALL_JENKINS_CLI:-0}"
INSTALL_CHEF_WORKSTATION="${INSTALL_CHEF_WORKSTATION:-0}"
JFROG_CLI_INSTALL_URL="https://install-cli.jfrog.io"
MISE_INSTALL_URL="https://mise.run"
GH_CLI_KEYRING_URL="https://cli.github.com/packages/githubcli-archive-keyring.gpg"
GH_CLI_APT_REPO="https://cli.github.com/packages"

install_dir() {
  mkdir -p "$HOME/.local/bin" "$HOME/.local/share/jenkins-cli"
}

install_linux_packages() {
  if ! has apt-get; then
    error "This script supports Debian/Ubuntu-style Linux systems with apt-get."
    exit 1
  fi

  info "Installing WSL Ubuntu/Linux base and release engineering utilities..."
  "${SUDO[@]}" apt-get update

  "${SUDO[@]}" apt-get install -y \
    apt-transport-https \
    build-essential \
    ca-certificates \
    curl \
    fd-find \
    git \
    gnupg \
    jq \
    lsb-release \
    openjdk-17-jre-headless \
    pipx \
    pkg-config \
    python3-pip \
    python3-venv \
    ripgrep \
    shellcheck \
    tmux \
    unzip \
    xz-utils \
    yq

  if apt-cache show btop >/dev/null 2>&1; then
    "${SUDO[@]}" apt-get install -y btop
  else
    warn "btop is not available from this apt repository. Skipping btop."
  fi
}

install_github_cli_linux() {
  if has gh; then
    info "GitHub CLI already installed."
    return 0
  fi

  info "Installing GitHub CLI for Debian/Ubuntu..."
  "${SUDO[@]}" mkdir -p -m 755 /etc/apt/keyrings
  curl -fsSL "$GH_CLI_KEYRING_URL" | "${SUDO[@]}" tee /etc/apt/keyrings/githubcli-archive-keyring.gpg >/dev/null
  "${SUDO[@]}" chmod go+r /etc/apt/keyrings/githubcli-archive-keyring.gpg

  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/githubcli-archive-keyring.gpg] $GH_CLI_APT_REPO stable main" |
    "${SUDO[@]}" tee /etc/apt/sources.list.d/github-cli.list >/dev/null

  "${SUDO[@]}" apt-get update
  "${SUDO[@]}" apt-get install -y gh
}

install_jfrog_cli() {
  if has jf; then
    info "JFrog CLI already installed as jf."
    return 0
  fi

  info "Installing JFrog CLI..."
  curl -fsSL "$JFROG_CLI_INSTALL_URL" | sh

  if ! has jf && has jfrog; then
    warn "JFrog CLI installed as jfrog rather than jf."
  fi
}

install_mise() {
  if ! has mise; then
    info "Installing mise..."
    curl -fsSL "$MISE_INSTALL_URL" | sh
  fi

  export PATH="$HOME/.local/bin:$HOME/.local/share/mise/shims:$PATH"

  if ! has mise; then
    error "mise installation completed, but mise is still not available on PATH."
    exit 1
  fi
}

configure_mise_shell_activation() {
  local user_shell
  user_shell="$(basename "${SHELL:-}")"

  case "$user_shell" in
    zsh)
      append_once 'eval "$(mise activate zsh)"' "${ZDOTDIR:-$HOME}/.zshrc"
      ;;
    bash)
      append_once 'eval "$(mise activate bash)"' "$HOME/.bashrc"
      ;;
    *)
      warn "Shell '$user_shell' not automatically configured. Add the appropriate 'mise activate' line manually."
      ;;
  esac

  eval "$(mise activate bash)"
}

install_mise_tools() {
  info "Provisioning language runtimes and release/IaC tooling via mise..."

  mise use --global python@3.11
  mise use --global node@20
  mise use --global terraform@1.8.0
  mise use --global terraform-docs@latest
  mise use --global helm@latest
  mise use --global kubectl@latest
  mise use --global tflint@latest || warn "Could not install tflint via mise."

  mise reshim || true
}

install_ansible_tools() {
  info "Installing Ansible tooling via pipx..."
  export PATH="$HOME/.local/bin:$PATH"
  pipx ensurepath >/dev/null 2>&1 || true

  if ! has ansible; then
    pipx install --include-deps ansible
  else
    info "Ansible already installed."
  fi

  if ! has ansible-lint; then
    pipx install ansible-lint || warn "ansible-lint install failed. You can install it later with: pipx install ansible-lint"
  fi
}

install_optional_jenkins_cli_wrapper() {
  if [[ "$INSTALL_JENKINS_CLI" != "1" ]]; then
    warn "Skipping Jenkins CLI wrapper because this ICE Release Engineering team reportedly does not manage Jenkins."
    warn "Re-run with INSTALL_JENKINS_CLI=1 only if internal guidance says Jenkins CLI is useful."
    return 0
  fi

  info "Installing optional Jenkins CLI wrapper..."
  install_dir

  cat >"$HOME/.local/bin/jcli" <<'JCLI'
#!/usr/bin/env bash
set -euo pipefail

JENKINS_CLI_DIR="${JENKINS_CLI_DIR:-$HOME/.local/share/jenkins-cli}"
JENKINS_CLI_JAR="$JENKINS_CLI_DIR/jenkins-cli.jar"

usage() {
  cat >&2 <<'USAGE'
Usage:
  export JENKINS_URL="https://jenkins.example.com"
  jcli help
  jcli who-am-i

Optional:
  export JENKINS_USER_ID="your-user"
  export JENKINS_API_TOKEN="your-api-token"
USAGE
}

if [[ -z "${JENKINS_URL:-}" ]]; then
  echo "Error: JENKINS_URL is not set." >&2
  usage
  exit 1
fi

mkdir -p "$JENKINS_CLI_DIR"

if [[ ! -s "$JENKINS_CLI_JAR" || "${1:-}" == "--refresh" ]]; then
  curl -fsSL "${JENKINS_URL%/}/jnlpJars/jenkins-cli.jar" -o "$JENKINS_CLI_JAR"
  if [[ "${1:-}" == "--refresh" ]]; then
    shift
  fi
fi

AUTH_ARGS=()
if [[ -n "${JENKINS_USER_ID:-}" && -n "${JENKINS_API_TOKEN:-}" ]]; then
  AUTH_ARGS=(-auth "${JENKINS_USER_ID}:${JENKINS_API_TOKEN}")
fi

exec java -jar "$JENKINS_CLI_JAR" -s "${JENKINS_URL%/}" "${AUTH_ARGS[@]}" "$@"
JCLI

  chmod +x "$HOME/.local/bin/jcli"
}

install_release_tool_check() {
  install_dir

  cat >"$HOME/.local/bin/release-tool-check-wsl" <<'CHECK'
#!/usr/bin/env bash
set -euo pipefail

tools=(
  git
  gh
  jf
  jq
  yq
  rg
  tmux
  terraform
  terraform-docs
  helm
  kubectl
  ansible
  ansible-playbook
  ansible-lint
  java
  python
  node
)

missing=0
for tool in "${tools[@]}"; do
  if command -v "$tool" >/dev/null 2>&1; then
    printf 'OK   %s -> %s\n' "$tool" "$(command -v "$tool")"
  else
    printf 'MISS %s\n' "$tool"
    missing=1
  fi
done

exit "$missing"
CHECK

  chmod +x "$HOME/.local/bin/release-tool-check-wsl"
}

verify_installation() {
  info "Verifying WSL/Linux tooling..."
  release-tool-check-wsl || warn "One or more tools are missing. Reload shell and re-run release-tool-check-wsl."

  if has mise; then
    mise doctor || true
  fi
}

info "Starting WSL Ubuntu/Linux bootstrap..."
install_dir
install_linux_packages
install_github_cli_linux
install_jfrog_cli
install_mise
configure_mise_shell_activation
install_mise_tools
install_ansible_tools
install_optional_jenkins_cli_wrapper
install_release_tool_check
verify_installation

success "WSL bootstrap complete. Restart your WSL shell, then run: mise doctor && release-tool-check-wsl"
'@

  Set-Content -Path $scriptPath -Value $script -Encoding UTF8
  Write-Success "Generated WSL bootstrap script at: $scriptPath"
}

function New-WindowsToolCheck {
  New-Item -ItemType Directory -Force -Path $BootstrapHome | Out-Null

  $scriptPath = Join-Path $BootstrapHome "release-tool-check-windows.ps1"
  $script = @'
$tools = @(
  "git",
  "gh",
  "jf",
  "terraform",
  "helm",
  "kubectl",
  "pwsh",
  "code",
  "wsl",
  "python",
  "node",
  "jq",
  "rg"
)

$missing = 0
foreach ($tool in $tools) {
  $cmd = Get-Command $tool -ErrorAction SilentlyContinue
  if ($cmd) {
    Write-Host ("OK   {0} -> {1}" -f $tool, $cmd.Source)
  } else {
    Write-Host ("MISS {0}" -f $tool) -ForegroundColor Yellow
    $missing = 1
  }
}

exit $missing
'@

  Set-Content -Path $scriptPath -Value $script -Encoding UTF8
  Write-Success "Generated Windows tool check at: $scriptPath"
}

function Verify-HostTools {
  Write-Info "Checking Windows host tooling..."

  $tools = @(
    "git",
    "gh",
    "jf",
    "terraform",
    "helm",
    "kubectl",
    "pwsh",
    "code",
    "wsl",
    "python",
    "node",
    "jq",
    "rg"
  )

  foreach ($tool in $tools) {
    $cmd = Get-Command $tool -ErrorAction SilentlyContinue
    if ($cmd) {
      Write-Success "$tool -> $($cmd.Source)"
    } else {
      Write-Warn "$tool not found on PATH."
    }
  }
}

Write-Info "ICE Release Engineering Windows bootstrap starting..."
Write-Info "Mode: $($(if ($Install) { 'INSTALL' } else { 'CHECK-ONLY' }))"
Write-Info "Running as admin: $(Test-IsAdmin)"

if (-not (Test-Winget)) {
  Write-Warn "winget is not available. Use Company Portal / Software Center or internal docs for approved software installation."
} else {
  Write-Success "winget is available."
}

# Core Windows host tools.
Install-WingetPackage -Id "Microsoft.WindowsTerminal" -Name "Windows Terminal"
Install-WingetPackage -Id "Microsoft.PowerShell" -Name "PowerShell 7"
Install-WingetPackage -Id "Git.Git" -Name "Git for Windows"
Install-WingetPackage -Id "GitHub.cli" -Name "GitHub CLI"
Install-WingetPackage -Id "Microsoft.VisualStudioCode" -Name "Visual Studio Code"
Install-WingetPackage -Id "JFrog.CLI" -Name "JFrog CLI"
Install-WingetPackage -Id "Hashicorp.Terraform" -Name "Terraform"
Install-WingetPackage -Id "Helm.Helm" -Name "Helm"
Install-WingetPackage -Id "Kubernetes.kubectl" -Name "kubectl"
Install-WingetPackage -Id "Python.Python.3.12" -Name "Python 3.12"
Install-WingetPackage -Id "OpenJS.NodeJS.LTS" -Name "Node.js LTS"
Install-WingetPackage -Id "jqlang.jq" -Name "jq"
Install-WingetPackage -Id "BurntSushi.ripgrep.MSVC" -Name "ripgrep"
Install-WingetPackage -Id "7zip.7zip" -Name "7-Zip"

# Optional tools.
if ($InstallOpenShiftCli) {
  Install-WingetPackage -Id "RedHat.OpenShift-Client" -Name "OpenShift CLI"
} else {
  Write-Info "Skipping OpenShift CLI by default. Use -InstallOpenShiftCli if approved/needed."
}

if ($InstallDockerDesktop) {
  Install-WingetPackage -Id "Docker.DockerDesktop" -Name "Docker Desktop"
} else {
  Write-Info "Skipping Docker Desktop by default. Use -InstallDockerDesktop if approved/needed."
}

if ($InstallChefWorkstation) {
  Install-WingetPackage -Id "ChefSoftware.ChefWorkstation" -Name "Chef Workstation"
} else {
  Write-Info "Skipping Chef Workstation by default. Use -InstallChefWorkstation only if approved/needed."
}

Configure-GitIfRequested
Install-VSCodeExtensionsIfRequested
Install-WSLIfRequested
New-WslBootstrapScript
New-WindowsToolCheck
Verify-HostTools

Write-Success "Windows bootstrap/check complete."
Write-Info "Generated files are in: $BootstrapHome"
Write-Info "Next suggested steps:"
Write-Info "  1. Confirm WSL/winget/Docker policy with ICE IT."
Write-Info "  2. If WSL is allowed, open Ubuntu and run: bash ~/ice-bootstrap/bootstrap-ice-release-eng-wsl-ubuntu.sh"
Write-Info "  3. Run Windows check: powershell -File $BootstrapHome\release-tool-check-windows.ps1"
