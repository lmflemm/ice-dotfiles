#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

# -----------------------------------------------------------------------------
# ICE Release Engineering Bootstrap - WSL Ubuntu/Linux Layer
#
# Use this inside WSL Ubuntu after corporate policy confirms WSL is allowed.
#
# Defaults are conservative:
# - installs user-level tools where possible
# - does not configure company URLs, tokens, SSH keys, or credentials
# - does not install Jenkins CLI by default because George indicated Jenkins is not
#   directly supported by this Release Engineering team
#
# Flags:
#   INSTALL_JENKINS_CLI=1 ./bootstrap-ice-release-eng-wsl-ubuntu.sh
#   INSTALL_CHEF_WORKSTATION=1 ./bootstrap-ice-release-eng-wsl-ubuntu.sh
# -----------------------------------------------------------------------------

info() { echo -e "\033[1;34m[INFO]\033[0m $1"; }
success() { echo -e "\033[1;32m[SUCCESS]\033[0m $1"; }
warn() { echo -e "\033[1;33m[WARN]\033[0m $1"; }
error() { echo -e "\033[1;31m[ERROR]\033[0m $1" >&2; }

has() { command -v "$1" >/dev/null 2>&1; }

append_once() {
  local line="$1"
  local file="$2"
  mkdir -p "$(dirname "$file")"
  touch "$file"
  if ! grep -Fqx "$line" "$file"; then
    echo "$line" >>"$file"
  fi
}

SUDO=()
if [[ "${EUID}" -ne 0 ]]; then
  SUDO=(sudo)
fi

INSTALL_JENKINS_CLI="${INSTALL_JENKINS_CLI:-0}"
INSTALL_CHEF_WORKSTATION="${INSTALL_CHEF_WORKSTATION:-0}"
JFROG_CLI_INSTALL_URL="https://install-cli.jfrog.io"
MISE_INSTALL_URL="https://mise.run"
GH_CLI_KEYRING_URL="https://cli.github.com/packages/githubcli-archive-keyring.gpg"
GH_CLI_APT_REPO="https://cli.github.com/packages"

install_dir() {
  mkdir -p "$HOME/.local/bin" "$HOME/.local/share/jenkins-cli"
}

install_linux_packages() {
  if ! has apt-get; then
    error "This script supports Debian/Ubuntu-style Linux systems with apt-get."
    exit 1
  fi

  info "Installing WSL Ubuntu/Linux base and release engineering utilities..."
  "${SUDO[@]}" apt-get update

  "${SUDO[@]}" apt-get install -y \
    apt-transport-https \
    build-essential \
    ca-certificates \
    curl \
    fd-find \
    git \
    gnupg \
    jq \
    lsb-release \
    openjdk-17-jre-headless \
    pipx \
    pkg-config \
    python3-pip \
    python3-venv \
    ripgrep \
    shellcheck \
    tmux \
    unzip \
    xz-utils \
    yq

  if apt-cache show btop >/dev/null 2>&1; then
    "${SUDO[@]}" apt-get install -y btop
  else
    warn "btop is not available from this apt repository. Skipping btop."
  fi
}

install_github_cli_linux() {
  if has gh; then
    info "GitHub CLI already installed."
    return 0
  fi

  info "Installing GitHub CLI for Debian/Ubuntu..."
  "${SUDO[@]}" mkdir -p -m 755 /etc/apt/keyrings
  curl -fsSL "$GH_CLI_KEYRING_URL" | "${SUDO[@]}" tee /etc/apt/keyrings/githubcli-archive-keyring.gpg >/dev/null
  "${SUDO[@]}" chmod go+r /etc/apt/keyrings/githubcli-archive-keyring.gpg

  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/githubcli-archive-keyring.gpg] $GH_CLI_APT_REPO stable main" |
    "${SUDO[@]}" tee /etc/apt/sources.list.d/github-cli.list >/dev/null

  "${SUDO[@]}" apt-get update
  "${SUDO[@]}" apt-get install -y gh
}

install_jfrog_cli() {
  if has jf; then
    info "JFrog CLI already installed as jf."
    return 0
  fi

  info "Installing JFrog CLI..."
  curl -fsSL "$JFROG_CLI_INSTALL_URL" | sh

  if ! has jf && has jfrog; then
    warn "JFrog CLI installed as jfrog rather than jf."
  fi
}

install_mise() {
  if ! has mise; then
    info "Installing mise..."
    curl -fsSL "$MISE_INSTALL_URL" | sh
  fi

  export PATH="$HOME/.local/bin:$HOME/.local/share/mise/shims:$PATH"

  if ! has mise; then
    error "mise installation completed, but mise is still not available on PATH."
    exit 1
  fi
}

configure_mise_shell_activation() {
  local user_shell
  user_shell="$(basename "${SHELL:-}")"

  case "$user_shell" in
    zsh)
      append_once 'eval "$(mise activate zsh)"' "${ZDOTDIR:-$HOME}/.zshrc"
      ;;
    bash)
      append_once 'eval "$(mise activate bash)"' "$HOME/.bashrc"
      ;;
    *)
      warn "Shell '$user_shell' not automatically configured. Add the appropriate 'mise activate' line manually."
      ;;
  esac

  eval "$(mise activate bash)"
}

install_mise_tools() {
  info "Provisioning language runtimes and release/IaC tooling via mise..."

  mise use --global python@3.11
  mise use --global node@20
  mise use --global terraform@1.8.0
  mise use --global terraform-docs@latest
  mise use --global helm@latest
  mise use --global kubectl@latest
  mise use --global tflint@latest || warn "Could not install tflint via mise."

  mise reshim || true
}

install_ansible_tools() {
  info "Installing Ansible tooling via pipx..."
  export PATH="$HOME/.local/bin:$PATH"
  pipx ensurepath >/dev/null 2>&1 || true

  if ! has ansible; then
    pipx install --include-deps ansible
  else
    info "Ansible already installed."
  fi

  if ! has ansible-lint; then
    pipx install ansible-lint || warn "ansible-lint install failed. You can install it later with: pipx install ansible-lint"
  fi
}

install_optional_jenkins_cli_wrapper() {
  if [[ "$INSTALL_JENKINS_CLI" != "1" ]]; then
    warn "Skipping Jenkins CLI wrapper because this ICE Release Engineering team reportedly does not manage Jenkins."
    warn "Re-run with INSTALL_JENKINS_CLI=1 only if internal guidance says Jenkins CLI is useful."
    return 0
  fi

  info "Installing optional Jenkins CLI wrapper..."
  install_dir

  cat >"$HOME/.local/bin/jcli" <<'JCLI'
#!/usr/bin/env bash
set -euo pipefail

JENKINS_CLI_DIR="${JENKINS_CLI_DIR:-$HOME/.local/share/jenkins-cli}"
JENKINS_CLI_JAR="$JENKINS_CLI_DIR/jenkins-cli.jar"

usage() {
  cat >&2 <<'USAGE'
Usage:
  export JENKINS_URL="https://jenkins.example.com"
  jcli help
  jcli who-am-i

Optional:
  export JENKINS_USER_ID="your-user"
  export JENKINS_API_TOKEN="your-api-token"
USAGE
}

if [[ -z "${JENKINS_URL:-}" ]]; then
  echo "Error: JENKINS_URL is not set." >&2
  usage
  exit 1
fi

mkdir -p "$JENKINS_CLI_DIR"

if [[ ! -s "$JENKINS_CLI_JAR" || "${1:-}" == "--refresh" ]]; then
  curl -fsSL "${JENKINS_URL%/}/jnlpJars/jenkins-cli.jar" -o "$JENKINS_CLI_JAR"
  if [[ "${1:-}" == "--refresh" ]]; then
    shift
  fi
fi

AUTH_ARGS=()
if [[ -n "${JENKINS_USER_ID:-}" && -n "${JENKINS_API_TOKEN:-}" ]]; then
  AUTH_ARGS=(-auth "${JENKINS_USER_ID}:${JENKINS_API_TOKEN}")
fi

exec java -jar "$JENKINS_CLI_JAR" -s "${JENKINS_URL%/}" "${AUTH_ARGS[@]}" "$@"
JCLI

  chmod +x "$HOME/.local/bin/jcli"
}

install_release_tool_check() {
  install_dir

  cat >"$HOME/.local/bin/release-tool-check-wsl" <<'CHECK'
#!/usr/bin/env bash
set -euo pipefail

tools=(
  git
  gh
  jf
  jq
  yq
  rg
  tmux
  terraform
  terraform-docs
  helm
  kubectl
  ansible
  ansible-playbook
  ansible-lint
  java
  python
  node
)

missing=0
for tool in "${tools[@]}"; do
  if command -v "$tool" >/dev/null 2>&1; then
    printf 'OK   %s -> %s\n' "$tool" "$(command -v "$tool")"
  else
    printf 'MISS %s\n' "$tool"
    missing=1
  fi
done

exit "$missing"
CHECK

  chmod +x "$HOME/.local/bin/release-tool-check-wsl"
}

verify_installation() {
  info "Verifying WSL/Linux tooling..."
  release-tool-check-wsl || warn "One or more tools are missing. Reload shell and re-run release-tool-check-wsl."

  if has mise; then
    mise doctor || true
  fi
}

info "Starting WSL Ubuntu/Linux bootstrap..."
install_dir
install_linux_packages
install_github_cli_linux
install_jfrog_cli
install_mise
configure_mise_shell_activation
install_mise_tools
install_ansible_tools
install_optional_jenkins_cli_wrapper
install_release_tool_check
verify_installation

success "WSL bootstrap complete. Restart your WSL shell, then run: mise doctor && release-tool-check-wsl"
