# ICE Release Engineering Windows-ready Bootstrap

This package is a Windows-ready counterpart to the original Bash bootstrap. It follows a **Windows host + optional WSL Ubuntu** model.

## Files

- `bootstrap-ice-release-eng-windows.ps1`
  - PowerShell script for Windows-native tools.
  - Default mode is **check-only**.
  - Use `-Install` to install packages with `winget`.
  - Use `-InstallWSL` only if ICE IT allows WSL.

- `bootstrap-ice-release-eng-wsl-ubuntu.sh`
  - Bash script for WSL Ubuntu/Linux tools.
  - Installs Linux CLI/release tools such as GitHub CLI, JFrog CLI, mise, Terraform, Helm, kubectl, Ansible, tmux, ripgrep, etc.
  - Jenkins CLI is disabled by default because George indicated the Release Engineering team does not directly support Jenkins.

- `README.md`
  - This file.

## Recommended corporate-laptop flow

### 1. Run Windows check-only mode first

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\bootstrap-ice-release-eng-windows.ps1
```

### 2. If allowed, install Windows-side tools

```powershell
.\bootstrap-ice-release-eng-windows.ps1 -Install
```

Optional flags:

```powershell
.\bootstrap-ice-release-eng-windows.ps1 -Install -InstallOpenShiftCli
.\bootstrap-ice-release-eng-windows.ps1 -Install -InstallDockerDesktop
.\bootstrap-ice-release-eng-windows.ps1 -Install -InstallChefWorkstation
.\bootstrap-ice-release-eng-windows.ps1 -Install -InstallVsCodeExtensions
```

### 3. If WSL is approved by company policy

```powershell
.\bootstrap-ice-release-eng-windows.ps1 -Install -InstallWSL
```

After Ubuntu is available:

```bash
mkdir -p ~/ice-bootstrap
# copy bootstrap-ice-release-eng-wsl-ubuntu.sh into ~/ice-bootstrap if needed
bash ~/ice-bootstrap/bootstrap-ice-release-eng-wsl-ubuntu.sh
```

## Important notes

- Do not hardcode company URLs, API tokens, credentials, or SSH keys in these scripts.
- Prefer ICE-approved Software Center / Company Portal instructions where available.
- WSL, Docker Desktop, Microsoft Store, winget, and VS Code extensions may be restricted by endpoint policy.
- Keep the Windows host and WSL responsibilities separate:
  - **Windows host:** PowerShell, Git for Windows, VS Code, Windows Terminal, VPN/SSO/certs, corporate tools.
  - **WSL Ubuntu:** Bash/Zsh, Linux CLI tooling, Ansible, Terraform/Helm/kubectl workflows, dotfiles.
- If WSL is not permitted, you can still use the Windows host tools and PowerShell workflow.

## Tooling focus for ICE Release Engineering

This version prioritizes the tools and concepts most aligned with the role:

- GitHub / GitHub Actions concepts
- Bitbucket / SVN source-control context
- JFrog Artifactory / artifact repository workflows
- Jira / SDLC traceability
- SonarQube quality gates
- Ansible / configuration automation
- OpenShift / Kubernetes CLI basics
- Terraform / IaC
- AI-assisted workflows using approved tools such as Claude, Copilot, or Cursor
